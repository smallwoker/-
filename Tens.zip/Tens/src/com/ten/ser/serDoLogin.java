package com.ten.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ten.dao.DaoStu;
import com.ten.dao.DaoTea;
import com.ten.dao.DaoAdmin;
import com.ten.user.Student;
import com.ten.user.Teacher;
import com.ten.user.Administrator;

@SuppressWarnings("serial")
public class serDoLogin extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public serDoLogin() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		try{
			int username = Integer.parseInt(request.getParameter("username"));
			String password = request.getParameter("password");
			String type  = null;
			if(request.getParameter("type")!=null)
				type = request.getParameter("type");
			if(type.equals("tea")){//�ж��Ƿ�Ϊ��ʦ
				Teacher tea = new Teacher(username,null,password);
				DaoTea logint = new DaoTea();
				tea = logint.loginTea(tea);
				if(tea!=null){
					session.setAttribute("teacher", tea);
					response.sendRedirect("/Tens/tea/teacher.jsp");
				}else{
					out.println("T�û��������벻��ȷ����˶Ժ�����!!");
					response.setHeader("refresh","2;url=/Tens/tea/teaLogin.jsp");
				}
			}else if(type.equals("admin")) {//�ж��Ƿ�Ϊ����Ա
				Administrator admin=new Administrator(username,null,password);
				DaoAdmin logint = new DaoAdmin();
				admin = logint.loginAdmin(admin);
				if(admin!=null) {
					session.setAttribute("administrator", admin);
					response.sendRedirect("/Tens/admin/admin.jsp");
				}else {
					out.println("A�û��������벻��ȷ����˶Ժ�����!!");
					response.setHeader("refresh","2;url=/Tens/admin/adminLogin.jsp");
				}
			}
			else if(type.equals("stu")){	//�ж��Ƿ�Ϊѧ��
				Student stu = new Student(username,null,password,null,null,0);
				out.println(stu.getSname()+"::"+stu.getSpassword()+"<br>");
				out.println(stu.getSname()+"::"+stu.getSpassword()+"<br>");
				DaoStu logins  = new DaoStu();
				stu = logins.loginStu(stu);
				if(stu!=null){
					session.setAttribute("student", stu);
					response.sendRedirect("/Tens/stu/student.jsp");
				}else{
					out.println("S�û��������벻��ȷ����˶Ժ�����!!");
					response.setHeader("refresh","2;url=/Ten/Login.jsp");
				}
			}else{
				out.println("�������¼��");
				response.setHeader("refresh","2;url=/Tens/Login.jsp");
			}
		}catch(Exception e){ e.printStackTrace();response.sendRedirect("/Tens/Login.jsp");}
		out.flush();
		out.close();
		}

	
	public void init() throws ServletException {
		// Put your code here
	}

}

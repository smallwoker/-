package com.ten.ser.tea;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ten.dao.DaoTea;
import com.ten.user.Teacher;

@SuppressWarnings("serial")
public class serDoInsertTea extends HttpServlet {

	 
	public serDoInsertTea() {
		super();
	}

	 
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	 
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		this.doPost(request, response);
		}

	 
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY><center>");
		try{
			request.setCharacterEncoding("utf-8");
			Teacher tea = new Teacher(request.getParameter("Tname"),request.getParameter("Tpassword"),request.getParameter("Tsex")
					,request.getParameter("Tdept"));
			DaoTea insert = new DaoTea();
			int rs = insert.insertTea(tea);
			if(rs!=0){
				out.println("���ӳɹ���"+tea.getTNo());
			}else{
				out.println("����ʧ��"+tea.getTNo());
			}
			response.sendRedirect("/Tens/admin/selectTea.jsp");
		}catch(Exception e){e.printStackTrace();}
		out.println("  </center></BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	 
	public void init() throws ServletException {
		 
	}

}


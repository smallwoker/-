package com.ten.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class serDoLogout extends HttpServlet {

	
	public serDoLogout() {
		super();
	}

	
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		try{
//			Object tea = session.getAttribute("teacher");
//			Object stu = session.getAttribute("student");
			
				session.removeAttribute("teacher");
				session.removeAttribute("student");
				session.removeAttribute("admin");
	
		}catch(Exception e){e.printStackTrace();};
		response.sendRedirect("/Tens/Login.jsp");
	}


	public void init() throws ServletException {
		// Put your code here
	}

}

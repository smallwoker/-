package com.ten.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ten.conn.Conn;
import com.ten.user.Course;
import com.ten.user.Student;
import com.ten.user.Teacher;

public class DaoTea {
	
	/**
	 * ��ʦ��¼
	 * **/
	public Teacher loginTea(Teacher tea){
		Teacher tea1 = null;
		try{
			String sql_loginT="select * from teacher where TNo=? and Tpassword=?;";
			Connection conn = new Conn().getConn();
			PreparedStatement pst = conn.prepareStatement(sql_loginT);
			pst.setInt(1, tea.getTNo());
			pst.setString(2,tea.getTpassword());
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				tea1 = new Teacher(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				System.out.println("teacher login select over");
			}
		}catch(Exception e){e.printStackTrace();}
		return tea1;
	}

/*
 * ��ѯ���н�ʦ
 * */
public Iterator<Teacher> selectTea(){
	List<Teacher> list = null;
	Iterator<Teacher> listall = null;
	try{
		String sql_select = "select TNo,Tname,Tpassword,Tsex,Tdept from teacher;";//��ѯȫ����ʦ��Ϣ;//��ѯ���е�sql���
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_select);
		ResultSet rs = pst.executeQuery();
		list = new ArrayList<Teacher>();
		while(rs.next()){				
			Teacher tea = new Teacher(rs.getInt("TNo"),rs.getString("Tname"),rs.getString("Tpassword"),rs.getString("Tsex")
					,rs.getString("Tdept"));
			list.add(tea);
		}
		listall = list.iterator();
	}catch(Exception e){e.printStackTrace();}
	return listall;
}
/*
 * ��ѯĳ����ʦ
 * */
public Teacher selectTea(int id){
	Teacher tea = null;
	try{
		String sql_selectone = "select * from teacher where TNo=?";//��ѯĳһ���γ�
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_selectone);
		pst.setInt(1, id);
		ResultSet rs = pst.executeQuery();
		if(rs.next()){
			tea = new Teacher(rs.getInt("TNo"),rs.getString("Tname"),rs.getString("Tpassword"),rs.getString("Tsex")
					,rs.getString("Tdept"));
		}
	}catch(Exception e){e.printStackTrace();}
	return tea;
}
/*
 * ��ѯĳ����ʦ��Ϣ��ģ����ѯ��
 * */
public Iterator<Teacher> selectTea(String aa){//aa��Ϊģ����ѯ�Ĺؼ���
	List<Teacher> list = null;
	Iterator<Teacher> listall = null;
	try{
		String sql_selectfuz = "select * from teacher where TNo=? or....";//fuzzy queryģ����ѯ
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_selectfuz);
		ResultSet rs = pst.executeQuery();
		list = new ArrayList<Teacher>();
		while(rs.next()){
			Teacher tea = new Teacher(rs.getInt("TNo"),rs.getString("Tname"),rs.getString("Tpassword"),rs.getString("Tsex")
					,rs.getString("Tdept"));
			list.add(tea);
		}
		listall = list.iterator();
	}catch(Exception e){e.printStackTrace();}
	return listall;
}
/*
 * �޸�ĳ����ʦ��Ϣ
 * */
public int updateTea(Teacher tea){
	int rs = 0;
	try{
		String sql_update = "update Teacher set Tname=?,Tpassword=?,Tsex=?,Tdept=? where TNo=?;";//�޸�һ����ʦ��Ϣ
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_update);
		pst.setString(1, tea.getTname());
		pst.setString(2, tea.getTpassword());
		pst.setString(3, tea.getTsex());
		pst.setString(4, tea.getTdept());
		pst.setInt(5, tea.getTNo());
		rs = pst.executeUpdate();
		if(rs!=0){
			System.out.println("Teacher_id"+tea.getTNo()+"update over!");
		}
	}catch(Exception e){e.printStackTrace();}
	return rs;
}
/*
 * ɾ��ĳ����ʦ��Ϣ
 * */
public int deleteTea(int id){
	int rs = 0;
	try{
		String sql_delete = "delete from teacher where TNo=?;";//ɾ��һ����ʦ��Ϣ
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_delete);
		pst.setInt(1, id);
		rs = pst.executeUpdate();
		if(rs!=0){
			System.out.println("Teacher_id"+id+"delete over!");
		}
	}catch(Exception e){e.printStackTrace();}
	return rs;
}
/*
 * ����һλ��ʦ��Ϣ
 * */
public int insertTea(Teacher tea){
	int rs = 0;
	try{
		String sql_insert = "insert into teacher(Tname,Tpassword,Tsex,Tdept) values(?,?,?,?);";//����һ����ʦ��Ϣ
		Connection conn = new Conn().getConn();
		PreparedStatement pst = conn.prepareStatement(sql_insert);
		pst.setString(1,tea.getTname());
		pst.setString(2, tea.getTpassword());
		pst.setString(3, tea.getTsex());
		pst.setString(4, tea.getTdept());
		rs = pst.executeUpdate();
		if(rs!=0){
			System.out.println("Teacher_id"+tea.getTNo()+"insert over!");
		}
	}catch(Exception e){e.printStackTrace();}
	return rs;
}


}
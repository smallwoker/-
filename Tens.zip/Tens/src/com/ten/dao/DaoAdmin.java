package com.ten.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ten.conn.Conn;
import com.ten.user.Administrator;

public class DaoAdmin {
	
	/**
	 * ����Ա��¼
	 * **/
	public Administrator loginAdmin(Administrator admin){
		Administrator admin1 = null;
		try{
			String sql_loginA="select * from administrator where ANo=? and Apassword=?;";
			Connection conn = new Conn().getConn();
			PreparedStatement pst = conn.prepareStatement(sql_loginA);
			pst.setInt(1, admin.getANo());
			pst.setString(2,admin.getApassword());
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				admin1 = new Administrator(rs.getInt("ANo"),rs.getString("Aname"),rs.getString("Apassword"));
			}
		}catch(Exception e){e.printStackTrace();}
		return admin1;
	}

}
package com.ten.user;

public class Major {
	private int MNo;
	private String Mname;
	
	public int getMNo() {
		return MNo;
	}
	public void setMNo(int mNo) {
		MNo = mNo;
	}
	public String getMname() {
		return Mname;
	}
	public void setMNo(String mname) {
		Mname = mname;
	}
	public Major( int mNo, String mname) {
		this.MNo = mNo;
		this.Mname = mname;
	}
}

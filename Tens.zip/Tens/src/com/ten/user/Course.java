package com.ten.user;

public class Course {
	private int CNo;
	private int MNo;
	private String Cname;
	private String Ccredit;
	private String Csemester;
	public int getCNo() {
		return CNo;
	}
	public void setCNo(int cNo) {
		CNo = cNo;
	}
	public int getMNo() {
		return MNo;
	}
	public void setMNo(int mNo) {
		MNo = mNo;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCcredit() {
		return Ccredit;
	}
	public void setCcredit(String Ccredit) {
		this.Ccredit = Ccredit;
	}
	public String getCsemester() {
		return Csemester;
	}
	public void setCsemester(String Csemester) {
		this.Csemester = Csemester;
	}
	 
	public Course(int cNo, String cname, String Ccredit) {
		this.CNo = cNo;
		this.Cname = cname;
		this.Ccredit = Ccredit;
	}
	public Course( String cname, String Ccredit) {
		this.Cname = cname;
		this.Ccredit = Ccredit;
	}
	public Course(int cNo,int mNo, String cname, String ccredit,String csemester) {
		this.CNo = cNo;
		this.MNo = mNo;
		this.Cname = cname;
		this.Ccredit = ccredit;
		this.Csemester = csemester;
	}
	public Course(int mNo, String cname, String ccredit,String csemester) {
		this.MNo = mNo;
		this.Cname = cname;
		this.Ccredit = ccredit;
		this.Csemester = csemester;
	}
	public Course(int cNo, String cname, String ccredit,String csemester,int mNo) {
		this.CNo = cNo;
		this.MNo = mNo;
		this.Cname = cname;
		this.Ccredit = ccredit;
		this.Csemester = csemester;
	}
}

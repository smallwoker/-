package com.ten.user;

public class Administrator {
	private int ANo;
	private String Aname;
	private String Apassword;
	public int getANo() {
		return ANo;
	}
	public void setANo(int aNo) {
		ANo = aNo;
	}
	public String getAname() {
		return Aname;
	}
	public void setAname(String aname) {
		Aname = aname;
	}
	public String getApassword() {
		return Apassword;
	}
	public void setTpassword(String apassword) {
		Apassword = apassword;
	}
	 
	public Administrator(int aNo, String aname, String apassword) {
		ANo = aNo;
		Aname = aname;
		Apassword = apassword;
	}
	public Administrator( String aname, String apassword) {
		Aname = aname;
		Apassword = apassword;
	}

}

